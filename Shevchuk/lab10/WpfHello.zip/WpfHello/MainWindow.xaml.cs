using System.ComponentModel;
using System.Windows;

namespace WpfHello
{
    // Клас з даними для прив'язки (Data Binding).
    // Інтерфейс INotifyPropertyChanged повідомляє вікно, що значення змінилось,
    // і WPF автоматично оновлює текст на екрані.
    public class MainViewModel : INotifyPropertyChanged
    {
        private string name = "";
        private string greeting = "";

        // Ім'я, яке вводить користувач (прив'язано до TextBox)
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        // Текст привітання (прив'язано до другого TextBlock)
        public string Greeting
        {
            get { return greeting; }
            set
            {
                greeting = value;
                OnPropertyChanged(nameof(Greeting));
            }
        }

        // Подія, на яку підписується WPF
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public partial class MainWindow : Window
    {
        private readonly MainViewModel viewModel = new MainViewModel();

        public MainWindow()
        {
            InitializeComponent();

            // Джерело даних для всіх прив'язок {Binding ...} у вікні
            DataContext = viewModel;
        }

        // Обробник події натискання кнопки "Підтвердити"
        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            // Отримуємо введений текст (завдяки прив'язці він уже є у viewModel.Name)
            string enteredName = viewModel.Name.Trim();

            if (enteredName == "")
            {
                viewModel.Greeting = "Будь ласка, введіть ім'я.";
            }
            else
            {
                viewModel.Greeting = $"Привіт, {enteredName}!";
            }
        }
    }
}
