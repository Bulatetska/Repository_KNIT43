using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfBooks
{
    // VIEWMODEL: зв'язує модель (Book) з представленням (MainWindow.xaml)
    public class BookViewModel : INotifyPropertyChanged
    {
        private Book? selectedBook;

        // Колекція книг. ObservableCollection сама повідомляє ListBox
        // про додавання та видалення елементів.
        public ObservableCollection<Book> Books { get; set; }

        // Книга, вибрана у списку
        public Book? SelectedBook
        {
            get { return selectedBook; }
            set
            {
                selectedBook = value;
                OnPropertyChanged();
            }
        }

        // Команда додавання нової книги
        private RelayCommand? addCommand;
        public RelayCommand AddCommand
        {
            get
            {
                return addCommand ??
                    (addCommand = new RelayCommand(obj =>
                    {
                        Book book = new Book
                        {
                            Title = "Нова книга",
                            Author = "Невідомий автор",
                            Year = DateTime.Now.Year
                        };
                        Books.Insert(0, book);   // додати на початок списку
                        SelectedBook = book;     // одразу вибрати її для редагування
                    }));
            }
        }

        // Команда видалення вибраної книги
        private RelayCommand? removeCommand;
        public RelayCommand RemoveCommand
        {
            get
            {
                return removeCommand ??
                    (removeCommand = new RelayCommand(obj =>
                    {
                        if (obj is Book book)
                        {
                            Books.Remove(book);
                            // вибрати першу книгу, що залишилась (або нічого, якщо список порожній)
                            SelectedBook = Books.Count > 0 ? Books[0] : null;
                        }
                    },
                    // кнопка "Видалити" активна тільки коли вибрано книгу
                    obj => obj is Book));
            }
        }

        public BookViewModel()
        {
            Books = new ObservableCollection<Book>
            {
                new Book { Title = "Кобзар", Author = "Тарас Шевченко", Year = 1840 },
                new Book { Title = "Тіні забутих предків", Author = "Михайло Коцюбинський", Year = 1911 },
                new Book { Title = "Лісова пісня", Author = "Леся Українка", Year = 1911 },
                new Book { Title = "Захар Беркут", Author = "Іван Франко", Year = 1883 }
            };
            SelectedBook = Books[0];
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
