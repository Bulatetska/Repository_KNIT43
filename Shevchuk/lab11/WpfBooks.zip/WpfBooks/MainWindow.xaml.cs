using System.Windows;

namespace WpfBooks
{
    // VIEW: у коді вікна немає логіки, тільки встановлення DataContext.
    // Уся логіка знаходиться в BookViewModel (патерн MVVM).
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new BookViewModel();
        }
    }
}
