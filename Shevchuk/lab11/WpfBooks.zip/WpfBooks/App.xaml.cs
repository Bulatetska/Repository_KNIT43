using System.Windows;

namespace WpfBooks
{
    public partial class App : Application
    {
    }
}
