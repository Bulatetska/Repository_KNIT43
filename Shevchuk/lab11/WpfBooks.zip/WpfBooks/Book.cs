using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfBooks
{
    // MODEL: клас книги.
    // Реалізує INotifyPropertyChanged, щоб при редагуванні полів
    // зміни одразу відображались у списку (ListBox).
    public class Book : INotifyPropertyChanged
    {
        private string title = "";
        private string author = "";
        private int year;

        public string Title
        {
            get { return title; }
            set
            {
                title = value;
                OnPropertyChanged();
            }
        }

        public string Author
        {
            get { return author; }
            set
            {
                author = value;
                OnPropertyChanged();
            }
        }

        public int Year
        {
            get { return year; }
            set
            {
                year = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        // [CallerMemberName] автоматично підставляє ім'я властивості, з якої викликано метод
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }
    }
}
