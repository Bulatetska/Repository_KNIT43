using System;

class Program
{
    static void Main()
    {
        int[,] matrix = new int[6, 9];
        Random rnd = new Random();
        int max = int.MinValue;
        int rowIndex = 0;
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                matrix[i, j] = rnd.Next(1, 100);
                Console.Write(matrix[i, j] + " ");
                if (matrix[i, j] > max)
                {
                    max = matrix[i, j];
                    rowIndex = i;
                }
            }
            Console.WriteLine();
        }
        int sum = 0;
        for (int j = 0; j < 9; j++) sum += matrix[rowIndex, j];
        Console.WriteLine($"Найбільший елемент: {max}, рядок: {rowIndex}, сума елементів рядка = {sum}");
    }
}