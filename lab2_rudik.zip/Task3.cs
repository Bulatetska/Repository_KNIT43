using System;

class Program
{
    static void Main()
    {
        Console.Write("Введіть кількість елементів: ");
        int n = int.Parse(Console.ReadLine());
        double[] a = new double[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write($"a[{i}] = ");
            a[i] = double.Parse(Console.ReadLine());
        }
        int posPairs = 0, zeroPairs = 0;
        for (int i = 0; i < n - 1; i++)
        {
            if (a[i] > 0 && a[i + 1] > 0) posPairs++;
            if (a[i] == 0 && a[i + 1] == 0) zeroPairs++;
        }
        Console.WriteLine($"Кількість сусідств двох додатних чисел: {posPairs}");
        Console.WriteLine($"Кількість сусідств двох нульових елементів: {zeroPairs}");
    }
}