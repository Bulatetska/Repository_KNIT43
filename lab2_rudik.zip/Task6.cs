using System;

class Program
{
    static void Main()
    {
        Console.Write("Введіть кількість елементів: ");
        int n = int.Parse(Console.ReadLine());
        double[] arr = new double[n];
        double sum = 0;
        for (int i = 0; i < n; i++)
        {
            Console.Write($"arr[{i}] = ");
            arr[i] = double.Parse(Console.ReadLine());
            sum += arr[i];
        }
        Console.WriteLine($"Сума елементів: {sum}");
    }
}