using System;

class Program
{
    static void Main()
    {
        Console.Write("Введіть розмір матриці n: ");
        int n = int.Parse(Console.ReadLine());
        double[,] matrix = new double[n, n];
        Random rnd = new Random();
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                matrix[i, j] = rnd.Next(1, 10);
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
        double max = matrix[0, 0];
        foreach (double x in matrix) if (x > max) max = x;
        Console.WriteLine($"Максимальний елемент: {max}");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (matrix[i, j] == max) matrix[i, j] = 0;
            }
        }
        Console.WriteLine("Результуюча матриця:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++) Console.Write(matrix[i, j] + " ");
            Console.WriteLine();
        }
    }
}