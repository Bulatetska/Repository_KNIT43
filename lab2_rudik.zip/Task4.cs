using System;

class Program
{
    static void Main()
    {
        Console.Write("Введіть n: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Введіть m: ");
        int m = int.Parse(Console.ReadLine());
        int[,] matrix = new int[n, m];
        Random rnd = new Random();
        double sum = 0;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                matrix[i, j] = rnd.Next(1, 10);
                sum += matrix[i, j];
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
        double avg = sum / (n * m);
        Console.WriteLine($"Середнє арифметичне = {avg:F2}");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (matrix[i, j] < avg) matrix[i, j] = -1;
                else if (matrix[i, j] > avg) matrix[i, j] = 1;
            }
        }
        Console.WriteLine("Результуюча матриця:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++) Console.Write(matrix[i, j] + " ");
            Console.WriteLine();
        }
    }
}