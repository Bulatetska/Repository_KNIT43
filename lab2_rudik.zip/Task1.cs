using System;

class Program
{
    static void Main()
    {
        Console.Write("Введіть кількість елементів масиву: ");
        int n = int.Parse(Console.ReadLine());
        int[] A = new int[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write($"A[{i}] = ");
            A[i] = int.Parse(Console.ReadLine());
        }
        int max = A[0];
        int index = 0;
        int count = 0;
        for (int i = 0; i < n; i++)
        {
            if (A[i] > max)
            {
                max = A[i];
                index = i;
            }
        }
        foreach (int x in A)
        {
            if (x == max) count++;
        }
        Console.WriteLine($"Максимальний елемент = {max}, зустрічається {count} разів, перший індекс = {index}");
    }
}