using System;
class Program {
    static void Main() {
        Console.Write("Введіть число: ");
        string num = Console.ReadLine();
        int sum = 0;
        foreach (char c in num) {
            sum += c - '0';
        }
        Console.WriteLine("Сума цифр числа: " + sum);
    }
}