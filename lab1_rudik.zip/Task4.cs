using System;
class Program {
    static void Main() {
        Console.Write("Введіть число (менше 100): ");
        int a = Convert.ToInt32(Console.ReadLine());
        int sum = 0, count = 0, temp = a;
        while (temp > 0) {
            sum += temp % 10;
            count++;
            temp /= 10;
        }
        Console.WriteLine("Кількість цифр: " + count);
        Console.WriteLine("Сума цифр: " + sum);
    }
}