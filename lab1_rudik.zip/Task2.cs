using System;
class Program {
    static void Main() {
        Console.WriteLine("To be or not to be");
        Console.WriteLine("\ Shakespeare \");
    }
}